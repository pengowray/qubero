Qubero sample archive. No template covers zip yet, so this file is the one that asks the file(1) rules what it is.
